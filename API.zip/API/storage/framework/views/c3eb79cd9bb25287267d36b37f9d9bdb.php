<table>
    <tr>
        <td>VENTAS REALIZADAS</td>
    </tr>

    <thead>
        <tr>
            <th>#</th>
            <th width="35" style="background: #ff7272">Cliente</th>
            <th width="35" style="background: #ff7272">Metodo de pago</th>
            <th width="35" style="background: #ff7272">Tipo de Moneda Total</th>
            <th width="35" style="background: #ff7272">Total</th>
            <th width="35" style="background: #ff7272">N° de Transaccion</th>
            <th width="35" style="background: #ff7272">Fecha de registro</th>
            <th width="35" style="background: #ff7272"> Region/Ciudad/Pais</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($sale->user->name.' '.$sale->user->surnmae); ?></td>
                <td><?php echo e($sale->method_payment); ?></td>
                <td><?php echo e($sale->currency_total); ?></td>
                <td><?php echo e($sale->total); ?> <?php echo e($sale->currency_payment); ?></td>
                <td><?php echo e($sale->n_transaccion); ?></td>
                <td><?php echo e($sale->created_at->format("Y-m-d h:i:s")); ?></td>
                <td><?php echo e($sale->sale_addres->country_region." ".
                        $sale->sale_addres->city." ".
                        $sale->sale_addres->company); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\Proyecto-Final-Angular-Laravel\PROYECTO_FINAL_VERSION_1\API\resources\views/sale/sale_export.blade.php ENDPATH**/ ?>